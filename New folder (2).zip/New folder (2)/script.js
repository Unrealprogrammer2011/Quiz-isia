// Islamic Quiz App - Main Logic
class QuizApp {
    constructor() {
        this.currentLevel = '';
        this.currentQuestions = [];
        this.currentQuestionIndex = 0;
        this.userAnswers = [];
        this.score = 0;
        this.timeLimit = null;
        this.timer = null;
        
        this.initializeElements();
        this.bindEvents();
        this.showScreen('main-menu');
        this.addSmoothTransitions();
    }

    initializeElements() {
        // Screen elements
        this.mainMenu = document.getElementById('main-menu');
        this.quizScreen = document.getElementById('quiz-screen');
        this.resultsScreen = document.getElementById('results-screen');
        this.reviewScreen = document.getElementById('review-screen');
        
        // Quiz elements
        this.currentLevelSpan = document.getElementById('current-level');
        this.questionCounter = document.getElementById('question-counter');
        this.progressBar = document.getElementById('progress');
        this.questionText = document.getElementById('question-text');
        this.optionButtons = document.querySelectorAll('.option-btn');
        
        // Control buttons
        this.prevBtn = document.getElementById('prev-btn');
        this.nextBtn = document.getElementById('next-btn');
        this.submitBtn = document.getElementById('submit-btn');
        
        // Results elements
        this.scorePercentage = document.getElementById('score-percentage');
        this.scoreText = document.getElementById('score-text');
        this.performanceTitle = document.getElementById('performance-title');
        this.performanceText = document.getElementById('performance-text');
        
        // Action buttons
        this.reviewBtn = document.getElementById('review-btn');
        this.retryBtn = document.getElementById('retry-btn');
        this.homeBtn = document.getElementById('home-btn');
        this.backToResultsBtn = document.getElementById('back-to-results');
        
        // Review content
        this.reviewContent = document.getElementById('review-content');
    }

    bindEvents() {
        // Level selection
        document.querySelectorAll('.level-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const level = btn.getAttribute('data-level');
                this.startQuiz(level);
            });
        });
        
        // Option selection
        this.optionButtons.forEach((btn, index) => {
            btn.addEventListener('click', () => {
                this.selectAnswer(index);
            });
        });
        
        // Navigation buttons
        this.prevBtn.addEventListener('click', () => this.previousQuestion());
        this.nextBtn.addEventListener('click', () => this.nextQuestion());
        this.submitBtn.addEventListener('click', () => this.submitQuiz());
        
        // Results buttons
        this.reviewBtn.addEventListener('click', () => this.showReview());
        this.retryBtn.addEventListener('click', () => this.retryQuiz());
        this.homeBtn.addEventListener('click', () => this.goHome());
        this.backToResultsBtn.addEventListener('click', () => this.showScreen('results-screen'));
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (this.quizScreen.classList.contains('hidden')) return;
            
            switch(e.key) {
                case '1':
                case '2':
                case '3':
                case '4':
                    const optionIndex = parseInt(e.key) - 1;
                    if (optionIndex < this.optionButtons.length) {
                        this.selectAnswer(optionIndex);
                    }
                    break;
                case 'ArrowLeft':
                    if (!this.prevBtn.disabled) this.previousQuestion();
                    break;
                case 'ArrowRight':
                case 'Enter':
                    if (!this.nextBtn.disabled && !this.nextBtn.classList.contains('hidden')) {
                        this.nextQuestion();
                    } else if (!this.submitBtn.disabled && !this.submitBtn.classList.contains('hidden')) {
                        this.submitQuiz();
                    }
                    break;
            }
        });
    }

    showScreen(screenId) {
        // Add loading transition
        const currentScreen = document.querySelector('.screen:not(.hidden)');
        if (currentScreen) {
            currentScreen.style.opacity = '0';
            currentScreen.style.transform = 'translateY(-20px)';
            
            setTimeout(() => {
                // Hide all screens
                document.querySelectorAll('.screen').forEach(screen => {
                    screen.classList.add('hidden');
                    screen.style.opacity = '';
                    screen.style.transform = '';
                });
                
                // Show target screen with animation
                const targetScreen = document.getElementById(screenId);
                targetScreen.classList.remove('hidden');
                targetScreen.style.opacity = '0';
                targetScreen.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    targetScreen.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
                    targetScreen.style.opacity = '1';
                    targetScreen.style.transform = 'translateY(0)';
                }, 50);
            }, 200);
        } else {
            // Initial load - no transition
            document.querySelectorAll('.screen').forEach(screen => {
                screen.classList.add('hidden');
            });
            document.getElementById(screenId).classList.remove('hidden');
        }
    }

    startQuiz(level) {
        this.currentLevel = level;
        this.currentQuestions = shuffleArray(quizData[level]);
        this.currentQuestionIndex = 0;
        this.userAnswers = new Array(this.currentQuestions.length).fill(null);
        this.score = 0;
        
        this.currentLevelSpan.textContent = level.charAt(0).toUpperCase() + level.slice(1);
        this.showScreen('quiz-screen');
        this.updateQuestion();
        this.updateNavigation();
    }

    updateQuestion() {
        const question = this.currentQuestions[this.currentQuestionIndex];
        
        // Update question counter and progress
        this.questionCounter.textContent = `Question ${this.currentQuestionIndex + 1} of ${this.currentQuestions.length}`;
        const progress = ((this.currentQuestionIndex + 1) / this.currentQuestions.length) * 100;
        this.progressBar.style.width = progress + '%';

        // Update question text
        this.questionText.textContent = question.question;

        // Update options and clear any previous styling
        this.optionButtons.forEach((btn, index) => {
            btn.textContent = question.options[index];
            btn.classList.remove('selected', 'correct', 'incorrect');
            
            // Show previous selection if exists
            if (this.userAnswers[this.currentQuestionIndex] === index) {
                btn.classList.add('selected');
            }
        });
        
        // Remove any existing feedback
        const existingFeedback = document.querySelector('.answer-feedback');
        if (existingFeedback) {
            existingFeedback.remove();
        }
    }

    selectAnswer(optionIndex) {
        // Add haptic feedback and sound
        this.playSelectSound();
        if ('vibrate' in navigator) {
            navigator.vibrate(50);
        }
        
        // Remove previous selection
        this.optionButtons.forEach(btn => {
            btn.classList.remove('selected');
        });
        
        // Add selection to clicked option with enhanced animation
        const selectedBtn = this.optionButtons[optionIndex];
        selectedBtn.classList.add('selected');
        
        // Store answer
        this.userAnswers[this.currentQuestionIndex] = optionIndex;
        
        // Update navigation
        this.updateNavigation();
    }
    
    playSelectSound() {
        // Create audio context for sound effects
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
            
            gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.1);
        } catch (e) {
            // Fallback - no sound if audio context fails
        }
    }

    updateNavigation() {
        // Update previous button
        this.prevBtn.disabled = this.currentQuestionIndex === 0;
        
        // Update next/submit buttons
        const isLastQuestion = this.currentQuestionIndex === this.currentQuestions.length - 1;
        
        if (isLastQuestion) {
            this.nextBtn.classList.add('hidden');
            this.submitBtn.classList.remove('hidden');
        } else {
            this.nextBtn.classList.remove('hidden');
            this.submitBtn.classList.add('hidden');
        }
    }

    previousQuestion() {
        if (this.currentQuestionIndex > 0) {
            this.currentQuestionIndex--;
            this.updateQuestion();
            this.updateNavigation();
        }
    }

    nextQuestion() {
        if (this.currentQuestionIndex < this.currentQuestions.length - 1) {
            // Show correct answer before moving to next question
            this.showCorrectAnswer();
            
            // Wait a moment to show the answer, then move to next question
            setTimeout(() => {
                this.currentQuestionIndex++;
                this.updateQuestion();
                this.updateNavigation();
            }, 2000); // Show answer for 2 seconds
        }
    }

    showCorrectAnswer() {
        const question = this.currentQuestions[this.currentQuestionIndex];
        const userAnswer = this.userAnswers[this.currentQuestionIndex];
        const correctAnswer = question.correct;
        
        // Mark all options with correct/incorrect styling
        this.optionButtons.forEach((btn, index) => {
            btn.classList.remove('selected');
            
            if (index === correctAnswer) {
                btn.classList.add('correct');
            }
            
            if (index === userAnswer && userAnswer !== correctAnswer) {
                btn.classList.add('incorrect');
            }
            
            if (index === userAnswer && userAnswer === correctAnswer) {
                btn.classList.add('selected', 'correct');
            }
        });
        
        // Disable navigation temporarily
        this.nextBtn.disabled = true;
        this.prevBtn.disabled = true;
        this.submitBtn.disabled = true;
        
        // Show feedback message
        this.showAnswerFeedback(userAnswer === correctAnswer);
    }

    showAnswerFeedback(isCorrect) {
        // Remove any existing feedback
        const existingFeedback = document.querySelector('.answer-feedback');
        if (existingFeedback) {
            existingFeedback.remove();
        }
        
        // Create feedback element
        const feedback = document.createElement('div');
        feedback.className = 'answer-feedback';
        feedback.innerHTML = isCorrect 
            ? '<span class="feedback-correct">✓ Correct! Well done!</span>'
            : '<span class="feedback-incorrect">✗ Incorrect. The correct answer is highlighted in green.</span>';
        
        // Insert feedback below options
        const optionsContainer = document.querySelector('.options-container');
        optionsContainer.parentNode.insertBefore(feedback, optionsContainer.nextSibling);
        
        // Re-enable navigation after showing feedback
        setTimeout(() => {
            this.nextBtn.disabled = false;
            this.prevBtn.disabled = this.currentQuestionIndex === 0;
            this.submitBtn.disabled = false;
            
            // Remove feedback when moving to next question
            if (feedback.parentNode) {
                feedback.remove();
            }
        }, 2000);
    }

    submitQuiz() {
        // Calculate score
        this.score = 0;
        for (let i = 0; i < this.currentQuestions.length; i++) {
            if (this.userAnswers[i] === this.currentQuestions[i].correct) {
                this.score++;
            }
        }
        
        this.showResults();
    }

    showResults() {
        const percentage = Math.round((this.score / this.currentQuestions.length) * 100);
        
        // Add confetti effect for good scores
        if (percentage >= 70) {
            this.createConfetti();
        }
        
        // Animate score counting up
        this.animateScore(percentage);

        // Performance message with enhanced feedback
        let title, message, color, emoji;
        if (percentage >= 90) {
            title = "Excellent! ماشاءالله";
            message = "Outstanding knowledge of Islam! You have demonstrated excellent understanding of Islamic teachings.";
            color = "#4CAF50";
            emoji = "🎆";
        } else if (percentage >= 80) {
            title = "Very Good! بارك الله فيك";
            message = "Great job! You have a strong foundation in Islamic knowledge. Keep up the good work!";
            color = "#66BB6A";
            emoji = "🎉";
        } else if (percentage >= 70) {
            title = "Good! الحمد لله";
            message = "Well done! Continue studying to strengthen your understanding of Islamic teachings.";
            color = "#FFC107";
            emoji = "👏";
        } else if (percentage >= 60) {
            title = "Fair - Keep Learning";
            message = "Not bad! There's room for improvement. Continue your journey of Islamic learning.";
            color = "#FF9800";
            emoji = "💪";
        } else {
            title = "Keep Striving! لا تيأس";
            message = "Don't give up! Continue studying Islamic teachings. Every step in learning is rewarded by Allah.";
            color = "#FF5722";
            emoji = "🌱";
        }

        this.performanceTitle.innerHTML = `${emoji} ${title}`;
        this.performanceText.textContent = message;
        this.performanceTitle.style.color = color;

        this.showScreen('results-screen');
    }
    
    animateScore(targetPercentage) {
        let currentPercent = 0;
        let currentScore = 0;
        const targetScore = this.score;
        
        const interval = setInterval(() => {
            if (currentPercent < targetPercentage) {
                currentPercent += Math.ceil(targetPercentage / 50);
                if (currentPercent > targetPercentage) currentPercent = targetPercentage;
                this.scorePercentage.textContent = currentPercent + '%';
            }
            
            if (currentScore < targetScore) {
                currentScore += 1;
                this.scoreText.textContent = `You scored ${currentScore} out of ${this.currentQuestions.length}`;
            }
            
            if (currentScore >= targetScore && currentPercent >= targetPercentage) {
                clearInterval(interval);
            }
        }, 30);
    }
    
    createConfetti() {
        const colors = ['#4CAF50', '#66BB6A', '#81C784', '#FFC107', '#FF9800'];
        const confettiContainer = document.createElement('div');
        confettiContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1000;
        `;
        
        for (let i = 0; i < 50; i++) {
            const confetti = document.createElement('div');
            const color = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.cssText = `
                position: absolute;
                width: 8px;
                height: 8px;
                background: ${color};
                left: ${Math.random() * 100}%;
                animation: confettiFall ${2 + Math.random() * 3}s linear forwards;
                transform: rotate(${Math.random() * 360}deg);
            `;
            confettiContainer.appendChild(confetti);
        }
        
        const confettiKeyframes = `
            @keyframes confettiFall {
                0% {
                    transform: translateY(-100vh) rotate(0deg);
                    opacity: 1;
                }
                100% {
                    transform: translateY(100vh) rotate(720deg);
                    opacity: 0;
                }
            }
        `;
        
        const style = document.createElement('style');
        style.textContent = confettiKeyframes;
        document.head.appendChild(style);
        document.body.appendChild(confettiContainer);
        
        // Remove confetti after animation
        setTimeout(() => {
            document.body.removeChild(confettiContainer);
        }, 5000);
    }

    showReview() {
        this.reviewContent.innerHTML = '';
        
        this.currentQuestions.forEach((question, index) => {
            const reviewItem = document.createElement('div');
            reviewItem.className = 'review-item';
            
            const userAnswer = this.userAnswers[index];
            const correctAnswer = question.correct;
            const isCorrect = userAnswer === correctAnswer;
            
            reviewItem.innerHTML = `
                <div class="review-question">
                    <h4>Question ${index + 1}</h4>
                    <p>${question.question}</p>
                </div>
                <div class="review-options">
                    ${question.options.map((option, optIndex) => {
                        let className = 'review-option';
                        if (optIndex === correctAnswer) className += ' correct';
                        if (optIndex === userAnswer && !isCorrect) className += ' incorrect';
                        if (optIndex === userAnswer) className += ' selected';
                        
                        return `<div class="${className}">${option}</div>`;
                    }).join('')}
                </div>
                <div class="review-result ${isCorrect ? 'correct' : 'incorrect'}">
                    ${isCorrect ? '✓ Correct' : '✗ Incorrect'}
                </div>
            `;
            
            this.reviewContent.appendChild(reviewItem);
        });
        
        this.showScreen('review-screen');
    }

    retryQuiz() {
        this.startQuiz(this.currentLevel);
    }

    goHome() {
        this.showScreen('main-menu');
    }

    addSmoothTransitions() {
        const style = document.createElement('style');
        style.textContent = `
            .screen {
                animation: fadeInUp 0.6s cubic-bezier(0.4, 0, 0.2, 1);
            }
            
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .option-btn {
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }
            
            .quiz-info {
                animation: slideInDown 0.5s ease-out;
            }
            
            @keyframes slideInDown {
                from {
                    opacity: 0;
                    transform: translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            .question-container {
                animation: questionSlide 0.5s ease-out;
            }
            
            @keyframes questionSlide {
                from {
                    opacity: 0;
                    transform: translateX(20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            .options-container {
                animation: optionsStagger 0.6s ease-out;
            }
            
            @keyframes optionsStagger {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        `;
        document.head.appendChild(style);
        
        // Add particle effects
        this.createParticleEffect();
    }
    
    createParticleEffect() {
        const particles = document.createElement('div');
        particles.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        `;
        
        for (let i = 0; i < 15; i++) {
            const particle = document.createElement('div');
            particle.style.cssText = `
                position: absolute;
                width: 4px;
                height: 4px;
                background: rgba(76, 175, 80, 0.6);
                border-radius: 50%;
                animation: float ${5 + Math.random() * 10}s infinite linear;
                left: ${Math.random() * 100}%;
                top: ${Math.random() * 100}%;
            `;
            particles.appendChild(particle);
        }
        
        const floatKeyframes = `
            @keyframes float {
                0% { transform: translateY(0px) rotate(0deg); opacity: 0; }
                10% { opacity: 1; }
                90% { opacity: 1; }
                100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
            }
        `;
        
        const style = document.createElement('style');
        style.textContent = floatKeyframes;
        document.head.appendChild(style);
        document.body.appendChild(particles);
    }
}

// Initialize the app when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new QuizApp();
});